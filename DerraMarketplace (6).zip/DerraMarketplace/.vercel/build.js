// This is a build script for Vercel deployment
const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

// Log the build process
console.log('Starting Vercel build process for Derra Marketplace...');

// Install dependencies
console.log('Installing dependencies...');
execSync('npm install', { stdio: 'inherit' });

// Build the client
console.log('Building the client...');
execSync('npm run build', { stdio: 'inherit' });

// Create the necessary directories for the serverless functions
console.log('Setting up serverless function directories...');
const apiDir = path.join(__dirname, '..', 'api');
const outputDir = path.join(__dirname, 'output', 'api');

if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

// Copy the API files
console.log('Copying API files...');
fs.readdirSync(apiDir).forEach(file => {
  const source = path.join(apiDir, file);
  const dest = path.join(outputDir, file);
  
  if (fs.statSync(source).isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    fs.readdirSync(source).forEach(subFile => {
      fs.copyFileSync(
        path.join(source, subFile), 
        path.join(dest, subFile)
      );
    });
  } else {
    fs.copyFileSync(source, dest);
  }
});

console.log('Build completed successfully!');