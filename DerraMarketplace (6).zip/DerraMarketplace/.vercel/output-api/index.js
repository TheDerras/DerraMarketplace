// This file acts as a bridge between Vercel's serverless functions and our Express app
import { app } from '../../api/_app.js';

// Export the Express app as a serverless function handler
export default function handler(req, res) {
  return app(req, res);
}