# Comprehensive Vercel Deployment Guide for Derra

This guide provides detailed instructions for deploying Derra to Vercel, addressing common challenges and offering multiple deployment approaches.

## Project Structure Overview

Derra has a complex structure that needs proper configuration for Vercel deployment:

1. **Frontend**: Vite-based React application in the `client` directory
2. **Backend**: Express API server with routes defined in `server/routes.ts`
3. **Vercel API Endpoints**: Next.js-compatible API routes in `pages/api` and `api` directories

## Deployment Option 1: Standalone API

This approach deploys only the API endpoints to Vercel and runs the frontend separately.

### Step 1: Prepare API files

```bash
# Replace package.json with Vercel-specific version
cp vercel-package.json package.json
```

### Step 2: Deploy to Vercel

1. Push your code to a Git repository (GitHub, GitLab, BitBucket)
2. Log in to Vercel Dashboard
3. Create a new project from your repository
4. Configure project settings:
   - Framework Preset: Next.js
   - Root Directory: ./
   - Build Command: node vercel-build.js
   - Output Directory: .next
5. Add environment variables:
   - SESSION_SECRET: [generate a secure random string]
   - Add any additional environment secrets needed (database credentials, etc.)
6. Click "Deploy"

### Step 3: Update frontend configuration

In your frontend code, update the API URL to point to your Vercel deployment:

```javascript
// client/src/lib/queryClient.ts
const API_BASE_URL = process.env.NODE_ENV === 'production'
  ? 'https://your-vercel-deployment-url.vercel.app' // Replace with your actual URL
  : '';
```

## Deployment Option 2: Full-Stack Deployment

This approach requires merging the Vite frontend with the Next.js API structure.

### Preparation Steps

1. Build the Vite frontend:
   ```bash
   cd client
   npm run build
   ```

2. Copy the built files to a public directory:
   ```bash
   mkdir -p public
   cp -r dist/* public/
   ```

3. Update package.json:
   ```bash
   cp vercel-package.json package.json
   ```

4. Deploy to Vercel (same as Option 1)

## Troubleshooting

### "No framework detected" Error

If Vercel doesn't detect your framework:

1. Ensure your `vercel.json` has the correct configuration:
   ```json
   {
     "framework": "nextjs",
     "builds": [
       { "src": "package.json", "use": "@vercel/next" },
       { "src": "api/**/*.js", "use": "@vercel/node" }
     ]
   }
   ```

2. Verify that `next.config.js` exists at the root level

3. Make sure you have `pages/index.js` and at least one file in `pages/api/`

### API Routes Not Working

If API routes return 404 errors:

1. Check that all API routes are properly defined as standalone Node.js functions:
   ```javascript
   // pages/api/example.js
   export default function handler(req, res) {
     res.json({ status: 'ok' });
   }
   ```

2. Make sure your `vercel.json` has the correct routes configuration:
   ```json
   {
     "routes": [
       { "src": "/api/(.*)", "dest": "/api/$1" }
     ]
   }
   ```

### Mixed Framework Issues

If you have issues with mixed frameworks:

1. Use the custom build script:
   ```json
   {
     "buildCommand": "node vercel-build.js"
   }
   ```

2. Ensure the build script correctly handles your project structure

## Additional Resources

- [Vercel Documentation](https://vercel.com/docs)
- [Next.js API Routes](https://nextjs.org/docs/api-routes/introduction)
- [Vercel Configuration Reference](https://vercel.com/docs/configuration)

## Demo Mode

For testing purposes, you can use demo credentials:
- Username: `demo_user`
- Password: `password123`