// Custom build script for Vercel
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('Starting custom build process for Derra...');

// Run the standard build process
console.log('Building frontend with Vite...');
execSync('npm run build', { stdio: 'inherit' });

// Create directories for API functions if they don't exist
console.log('Setting up API function directories...');
const apiDirs = [
  'api/auth',
  'api/businesses',
  'api/categories', 
  'api/messages',
  'api/notifications',
  'api/subscription',
  'api/users'
];

apiDirs.forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

console.log('Build completed!');